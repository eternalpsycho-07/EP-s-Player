# EP's Video — Android 16-ready source project

An original AMOLED-dark Android video player built with Kotlin, Jetpack Compose, and AndroidX Media3 ExoPlayer.

## Included
- AMOLED-black visual theme with violet accents and translucent-card styling
- One UI-inspired rounded surfaces, comfortable touch targets, and bottom navigation
- Safe-drawing inset handling for status bar, camera cutout, and gesture navigation
- Responsive Compose layout intended for the large, high-resolution Galaxy S26 Ultra display
- Library screen backed by Android MediaStore
- System document picker for opening a video without broad library permission
- Video list with title, size and duration
- Playback screen using Media3's PlayerView with built-in playback controls
- Play/pause, seek, 10-second skip, playback speed menu, and track selection through Media3 controls
- Settings screen with theme / playback information
- No ad SDKs, promotional screens, or app recommendations
- Scoped-media access and runtime permission handling for library scanning

## Build requirements
- Android Studio with Android SDK Platform 36 installed
- JDK 17 or newer (Android Studio's bundled JDK is recommended)
- Internet access for Gradle dependency resolution

## Build an APK
1. Extract this ZIP.
2. Open the `EPsVideo-Final` folder in Android Studio.
3. Allow Gradle sync to complete.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Debug APK output: `app/build/outputs/apk/debug/app-debug.apk`.

CLI build from an environment with Gradle 8.11.1+ installed:
`gradle assembleDebug`

## Galaxy S26 Ultra / One UI
The project targets Android API 36 and is styled for a Samsung-style experience: AMOLED dark surfaces, rounded cards, clear hierarchy, and large touch-friendly controls. Safe drawing insets are applied so the main interface avoids system bars and the camera cutout. The layout adapts through Jetpack Compose, while playback controls are provided by AndroidX Media3. It does not depend on private Samsung APIs, so it can also run on other Android devices.

The APK still needs to be built and tested on the actual Galaxy S26 Ultra to verify playback, system-bar behavior, HDR formats, gesture navigation, rotation, and device-specific codec support. This source project has not yet been compiled or tested on that phone; no source project can guarantee zero crashes across all devices and media files.

## Format support
Media3 uses platform decoders. Supported containers, audio/video codecs, HDR profiles, and subtitle formats vary by Android version and hardware. This build does not bundle FFmpeg and does not claim universal codec support. Unsupported formats may fail to play gracefully.

## Licensing
This is an original implementation; it does not include MX Player proprietary source code, artwork, or branding. AndroidX / Media3 and other dependencies remain subject to their respective licenses.


## Video enhancement status (important)

The player includes an enhancement-status panel so the app does not misrepresent capabilities:
- **Video upscaling:** Android/Media3 scales decoded frames for display. AI super-resolution is not implemented in this version; true AI upscaling would require an optimized on-device model and GPU/NPU processing, with battery and thermal costs.
- **MEMC / motion smoothing:** frame interpolation is not implemented. It requires generating intermediate frames using an interpolation model or a supported device-specific pipeline. Android does not expose a universal public switch that lets third-party apps turn on Samsung system-level motion processing.
- These limitations are explicit in the UI; there are no fake switches claiming these features are active.

A future implementation should benchmark on the Galaxy S26 Ultra and provide a thermal/battery-aware opt-in mode before enabling ML frame interpolation or super-resolution.
