package com.epsvideo.player

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.text.format.Formatter
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.util.Locale

private val Void = Color(0xFF050507)
private val Panel = Color(0xFF13121A)
private val Panel2 = Color(0xFF1B1924)
private val Violet = Color(0xFFB8A3FF)
private val TextMain = Color(0xFFF6F3FF)
private val TextMuted = Color(0xFF9D98AD)
private val Border = Color(0x2EB8A3FF)

data class VideoFile(val uri: Uri, val title: String, val durationMs: Long, val sizeBytes: Long)

private enum class Screen { LIBRARY, PLAYER, SETTINGS }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(5, 5, 7)
        window.navigationBarColor = android.graphics.Color.rgb(5, 5, 7)
        if (Build.VERSION.SDK_INT >= 29) {
            window.isNavigationBarContrastEnforced = false
            window.isStatusBarContrastEnforced = false
        }
        setContent { EPsVideoApp() }
    }
}

@Composable
private fun EPsVideoApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var screen by remember { mutableStateOf(Screen.LIBRARY) }
    var videos by remember { mutableStateOf(emptyList<VideoFile>()) }
    var selected by remember { mutableStateOf<VideoFile?>(null) }
    var customUri by remember { mutableStateOf<Uri?>(null) }
    var customName by remember { mutableStateOf("") }
    var search by remember { mutableStateOf("") }
    var toastMessage by remember { mutableStateOf<String?>(null) }
    var hasPermission by remember { mutableStateOf(hasVideoPermission(context)) }
    var loading by remember { mutableStateOf(false) }
    var speed by remember { mutableFloatStateOf(1f) }

    val player = remember {
        ExoPlayer.Builder(context).build().apply {
            playWhenReady = false
            repeatMode = Player.REPEAT_MODE_OFF
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasPermission = granted
        if (granted) videos = queryVideos(context)
    }

    val openDocument = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            customUri = uri
            customName = uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':') ?: "Selected video"
            selected = null
            player.setMediaItem(MediaItem.fromUri(uri))
            player.prepare()
            player.playWhenReady = true
            screen = Screen.PLAYER
        }
    }

    fun playVideo(video: VideoFile) {
        selected = video
        customUri = null
        player.setMediaItem(MediaItem.fromUri(video.uri))
        player.prepare()
        player.playWhenReady = true
        screen = Screen.PLAYER
    }

    DisposableEffect(Unit) { onDispose { player.release() } }

    LaunchedEffect(Unit) {
        if (hasPermission) {
            loading = true
            videos = queryVideos(context)
            loading = false
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Violet, onPrimary = Void, background = Void, surface = Panel,
        onSurface = TextMain, secondary = Violet, onBackground = TextMain
    )) {
        Surface(Modifier.fillMaxSize(), color = Void) {
            // Safe drawing insets keep the One UI-inspired layout clear of the
            // S26 Ultra status bar, camera cutout, and gesture-navigation area.
            Column(
                Modifier.fillMaxSize()
                    .windowInsetsPadding(WindowInsets.safeDrawing)
                    .background(
                        Brush.verticalGradient(listOf(Color(0xFF15121E), Void, Void))
                    )
            ) {
                Header(
                    onOpen = { openDocument.launch(arrayOf("video/*")) },
                    onSettings = { screen = Screen.SETTINGS },
                    onLibrary = { screen = Screen.LIBRARY }
                )
                when (screen) {
                    Screen.LIBRARY -> LibraryScreen(
                        videos = videos.filter { it.title.contains(search, ignoreCase = true) },
                        search = search,
                        onSearch = { search = it },
                        loading = loading,
                        permissionGranted = hasPermission,
                        onPermission = {
                            val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
                            else Manifest.permission.READ_EXTERNAL_STORAGE
                            permissionLauncher.launch(permission)
                        },
                        onRefresh = {
                            loading = true
                            videos = queryVideos(context)
                            loading = false
                        },
                        onOpen = { openDocument.launch(arrayOf("video/*")) },
                        onPlay = { playVideo(it) }
                    )
                    Screen.PLAYER -> PlayerScreen(
                        player = player,
                        title = selected?.title ?: customName.ifBlank { "Now playing" },
                        onBack = { screen = Screen.LIBRARY },
                        speed = speed,
                        onSpeed = { newSpeed ->
                            speed = newSpeed
                            player.setPlaybackSpeed(newSpeed)
                        },
                        onError = { message -> toastMessage = message }
                    )
                    Screen.SETTINGS -> SettingsScreen(
                        onBack = { screen = Screen.LIBRARY },
                        count = videos.size
                    )
                }
                BottomBar(screen = screen, onChange = { screen = it })
            }
        }
    }
}

private fun hasVideoPermission(context: android.content.Context): Boolean {
    if (Build.VERSION.SDK_INT < 23) return true
    val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
    else Manifest.permission.READ_EXTERNAL_STORAGE
    return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
}

@Composable
private fun Header(onOpen: () -> Unit, onSettings: () -> Unit, onLibrary: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(start = 20.dp, end = 14.dp, top = 15.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(48.dp).clip(RoundedCornerShape(16.dp))
                .background(Brush.linearGradient(listOf(Color(0xFFB8A3FF), Color(0xFF453477)))),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Rounded.PlayCircle, null, tint = Void, modifier = Modifier.size(29.dp)) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("EP's Video", color = TextMain, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Text("YOUR PRIVATE MEDIA SPACE", color = TextMuted, fontSize = 9.sp, letterSpacing = 1.35.sp)
        }
        IconButton(onClick = onOpen) { Icon(Icons.Rounded.FolderOpen, "Open file", tint = Violet) }
        IconButton(onClick = onSettings) { Icon(Icons.Rounded.Tune, "Settings", tint = TextMuted) }
    }
}

@Composable
private fun LibraryScreen(
    videos: List<VideoFile>,
    search: String,
    onSearch: (String) -> Unit,
    loading: Boolean,
    permissionGranted: Boolean,
    onPermission: () -> Unit,
    onRefresh: () -> Unit,
    onOpen: () -> Unit,
    onPlay: (VideoFile) -> Unit
) {
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        GlassPanel(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("YOUR LIBRARY", color = Violet, fontSize = 10.sp, letterSpacing = 1.8.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(5.dp))
                    Text("Every frame, in its place.", color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                    Text("${videos.size} videos available on this device", color = TextMuted, fontSize = 12.sp)
                }
                Icon(Icons.Rounded.AutoAwesome, null, tint = Violet, modifier = Modifier.size(27.dp))
            }
        }
        Spacer(Modifier.height(14.dp))
        OutlinedTextField(
            value = search, onValueChange = onSearch,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Search your videos", color = TextMuted) },
            leadingIcon = { Icon(Icons.Rounded.Search, null, tint = TextMuted) },
            trailingIcon = { if (search.isNotEmpty()) IconButton(onClick = { onSearch("") }) { Icon(Icons.Rounded.Close, "Clear") } },
            singleLine = true,
            shape = RoundedCornerShape(17.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Violet, unfocusedBorderColor = Border,
                focusedContainerColor = Panel, unfocusedContainerColor = Panel,
                focusedTextColor = TextMain, unfocusedTextColor = TextMain
            )
        )
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("RECENT VIDEOS", color = TextMuted, fontSize = 10.sp, letterSpacing = 1.6.sp, fontWeight = FontWeight.Bold)
            TextButton(onClick = onRefresh) { Icon(Icons.Rounded.Refresh, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Refresh") }
        }
        when {
            !permissionGranted -> EmptyState(
                icon = Icons.Rounded.VideoLibrary,
                title = "Bring your library to life",
                body = "Allow video access to list local videos. You can also open a single file without granting library access.",
                action = "Allow video access", onAction = onPermission, secondary = "Open a video", onSecondary = onOpen
            )
            loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Violet) }
            videos.isEmpty() -> EmptyState(
                icon = Icons.Rounded.Movie,
                title = if (search.isBlank()) "A little quiet in here" else "No matching videos",
                body = if (search.isBlank()) "No local videos were found. Open a video file to start watching." else "Try another title or clear your search.",
                action = if (search.isBlank()) "Open a video" else "Clear search",
                onAction = if (search.isBlank()) onOpen else ({ onSearch("") })
            )
            else -> LazyColumn(
                Modifier.fillMaxSize(),
                contentPadding = PaddingValues(bottom = 12.dp),
                verticalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                items(videos, key = { it.uri.toString() }) { video ->
                    VideoRow(video = video, onClick = { onPlay(video) })
                }
            }
        }
    }
}

@Composable
private fun VideoRow(video: VideoFile, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(19.dp))
            .background(Panel.copy(alpha = 0.94f))
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(width = 82.dp, height = 62.dp).clip(RoundedCornerShape(13.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF28213C), Color(0xFF100F15)))),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Rounded.Movie, null, tint = Violet, modifier = Modifier.size(30.dp))
            Text(formatTime(video.durationMs), Modifier.align(Alignment.BottomEnd).padding(4.dp)
                .clip(RoundedCornerShape(5.dp)).background(Color(0xCC050507)).padding(horizontal = 4.dp, vertical = 2.dp),
                color = TextMain, fontSize = 9.sp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(video.title, color = TextMain, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(5.dp))
            Text(Formatter.formatFileSize(androidx.compose.ui.platform.LocalContext.current, video.sizeBytes), color = TextMuted, fontSize = 11.sp)
        }
        Icon(Icons.Rounded.PlayCircle, null, tint = Violet, modifier = Modifier.size(30.dp))
    }
}

@Composable
private fun PlayerScreen(
    player: ExoPlayer,
    title: String,
    onBack: () -> Unit,
    speed: Float,
    onSpeed: (Float) -> Unit,
    onError: (String) -> Unit
) {
    var showSpeed by remember { mutableStateOf(false) }
    var playbackError by remember { mutableStateOf<String?>(null) }
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                playbackError = "This file couldn't be played by the current device decoder."
                onError(error.message ?: "Playback error")
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
            IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, "Back", tint = TextMain) }
            Column(Modifier.weight(1f)) {
                Text("NOW PLAYING", color = Violet, fontSize = 10.sp, letterSpacing = 1.6.sp, fontWeight = FontWeight.Bold)
                Text(title, color = TextMain, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Box {
                TextButton(onClick = { showSpeed = true }) { Text("${speed}×", color = Violet, fontWeight = FontWeight.Bold) }
                DropdownMenu(expanded = showSpeed, onDismissRequest = { showSpeed = false }, modifier = Modifier.background(Panel)) {
                    listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { rate ->
                        DropdownMenuItem(text = { Text("${rate}×", color = if (rate == speed) Violet else TextMain) },
                            onClick = { onSpeed(rate); showSpeed = false })
                    }
                }
            }
        }
        Box(
            Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(24.dp))
                .background(Color.Black)
        ) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { viewContext ->
                    PlayerView(viewContext).apply {
                        this.player = player
                        useController = true
                        controllerAutoShow = true
                        setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
                        setKeepContentOnPlayerReset(true)
                        setShutterBackgroundColor(android.graphics.Color.BLACK)
                    }
                },
                update = { it.player = player }
            )
            if (playbackError != null) {
                Column(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                        .background(Color(0xEE17131E)).padding(16.dp)
                ) {
                    Text("Unable to play this video", color = TextMain, fontWeight = FontWeight.SemiBold)
                    Text(playbackError!!, color = TextMuted, fontSize = 12.sp)
                    TextButton(onClick = { playbackError = null }) { Text("Dismiss", color = Violet) }
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        GlassPanel(Modifier.fillMaxWidth()) {
            Text("PICTURE ENHANCEMENT", color = Violet, fontSize = 10.sp, letterSpacing = 1.6.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.Top) {
                Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Panel2), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.AutoAwesome, null, tint = Violet, modifier = Modifier.size(20.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Video upscaling", color = TextMain, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    Text("The player scales video to the screen. AI super-resolution is not yet implemented.", color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                }
                Surface(shape = RoundedCornerShape(8.dp), color = Color(0xFF29213D)) {
                    Text("BASIC", Modifier.padding(horizontal = 8.dp, vertical = 5.dp), color = Violet, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
            HorizontalDivider(color = Border, modifier = Modifier.padding(vertical = 12.dp))
            Row(verticalAlignment = Alignment.Top) {
                Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Panel2), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.SlowMotionVideo, null, tint = Violet, modifier = Modifier.size(20.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("MEMC / motion smoothing", color = TextMain, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    Text("Frame interpolation needs a supported processing pipeline. Android does not provide a universal app switch for Samsung's system-level motion processing.", color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
                }
                Surface(shape = RoundedCornerShape(8.dp), color = Panel2) {
                    Text("DEVICE-DEPENDENT", Modifier.padding(horizontal = 7.dp, vertical = 5.dp), color = TextMuted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        GlassPanel(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.GraphicEq, null, tint = Violet)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("Playback engine", color = TextMain, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Text("AndroidX Media3 · device-supported codecs", color = TextMuted, fontSize = 11.sp)
                }
                Surface(shape = CircleShape, color = Color(0xFF29213D)) {
                    Text("LIVE", Modifier.padding(horizontal = 10.dp, vertical = 6.dp), color = Violet, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(onBack: () -> Unit, count: Int) {
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Rounded.ArrowBack, "Back", tint = TextMain) }
            Text("Settings", color = TextMain, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        GlassPanel(Modifier.fillMaxWidth()) {
            Text("APPEARANCE", color = Violet, fontSize = 10.sp, letterSpacing = 1.6.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            SettingRow(Icons.Rounded.DarkMode, "AMOLED dark mode", "Pure-black canvas with violet glass accents")
            HorizontalDivider(color = Border, modifier = Modifier.padding(vertical = 12.dp))
            SettingRow(Icons.Rounded.BlurOn, "Liquid glass", "Translucent surfaces with subtle outlines")
        }
        GlassPanel(Modifier.fillMaxWidth()) {
            Text("PLAYBACK", color = Violet, fontSize = 10.sp, letterSpacing = 1.6.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            SettingRow(Icons.Rounded.Speed, "Playback speed", "Change speed from the player screen")
            HorizontalDivider(color = Border, modifier = Modifier.padding(vertical = 12.dp))
            SettingRow(Icons.Rounded.Subtitles, "Subtitles and audio tracks", "Available through player controls when supported")
            HorizontalDivider(color = Border, modifier = Modifier.padding(vertical = 12.dp))
            SettingRow(Icons.Rounded.AutoAwesome, "Video upscaling", "Standard screen scaling only; AI super-resolution is not implemented")
            HorizontalDivider(color = Border, modifier = Modifier.padding(vertical = 12.dp))
            SettingRow(Icons.Rounded.SlowMotionVideo, "MEMC / motion smoothing", "Requires a supported interpolation pipeline; not exposed as a universal Android app control")
        }
        GlassPanel(Modifier.fillMaxWidth()) {
            Text("ABOUT", color = Violet, fontSize = 10.sp, letterSpacing = 1.6.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            SettingRow(Icons.Rounded.VideoLibrary, "Local library", "$count videos indexed")
            HorizontalDivider(color = Border, modifier = Modifier.padding(vertical = 12.dp))
            SettingRow(Icons.Rounded.Shield, "Private by design", "No ad SDKs, recommendations, or analytics SDKs")
            HorizontalDivider(color = Border, modifier = Modifier.padding(vertical = 12.dp))
            SettingRow(Icons.Rounded.Info, "Version", "EP's Video 1.1.0 · Target Android 16 (API 36)")
        }
    }
}

@Composable
private fun SettingRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, detail: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Panel2), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Violet, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, color = TextMain, fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Text(detail, color = TextMuted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun EmptyState(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    body: String,
    action: String,
    onAction: () -> Unit,
    secondary: String? = null,
    onSecondary: (() -> Unit)? = null
) {
    Column(
        Modifier.fillMaxWidth().heightIn(min = 260.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(Modifier.size(78.dp).clip(CircleShape).background(Panel2), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Violet, modifier = Modifier.size(36.dp))
        }
        Spacer(Modifier.height(17.dp))
        Text(title, color = TextMain, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(7.dp))
        Text(body, color = TextMuted, fontSize = 12.sp, lineHeight = 18.sp, modifier = Modifier.widthIn(max = 300.dp))
        Spacer(Modifier.height(18.dp))
        Button(onClick = onAction, colors = ButtonDefaults.buttonColors(containerColor = Violet, contentColor = Void), shape = RoundedCornerShape(15.dp)) {
            Text(action, fontWeight = FontWeight.Bold)
        }
        if (secondary != null && onSecondary != null) {
            TextButton(onClick = onSecondary) { Text(secondary, color = Violet) }
        }
    }
}

@Composable
private fun BottomBar(screen: Screen, onChange: (Screen) -> Unit) {
    NavigationBar(containerColor = Color(0xFF09090D), contentColor = TextMain, tonalElevation = 0.dp) {
        NavigationBarItem(
            selected = screen == Screen.LIBRARY,
            onClick = { onChange(Screen.LIBRARY) },
            icon = { Icon(Icons.Rounded.VideoLibrary, null) },
            label = { Text("Library", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = Violet, selectedTextColor = Violet,
                indicatorColor = Color(0xFF29213D), unselectedIconColor = TextMuted, unselectedTextColor = TextMuted)
        )
        NavigationBarItem(
            selected = screen == Screen.PLAYER,
            onClick = { onChange(Screen.PLAYER) },
            icon = { Icon(Icons.Rounded.PlayCircle, null) },
            label = { Text("Player", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = Violet, selectedTextColor = Violet,
                indicatorColor = Color(0xFF29213D), unselectedIconColor = TextMuted, unselectedTextColor = TextMuted)
        )
        NavigationBarItem(
            selected = screen == Screen.SETTINGS,
            onClick = { onChange(Screen.SETTINGS) },
            icon = { Icon(Icons.Rounded.Settings, null) },
            label = { Text("Settings", fontSize = 10.sp) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = Violet, selectedTextColor = Violet,
                indicatorColor = Color(0xFF29213D), unselectedIconColor = TextMuted, unselectedTextColor = TextMuted)
        )
    }
}

@Composable
private fun GlassPanel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(23.dp))
            .background(Brush.linearGradient(listOf(Color(0xF21B1925), Color(0xE90E0D13))))
            .then(Modifier)
            .padding(16.dp),
        content = content
    )
}

private fun queryVideos(context: android.content.Context): List<VideoFile> {
    val app = context.applicationContext
    val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
    val projection = arrayOf(
        MediaStore.Video.Media._ID,
        MediaStore.Video.Media.DISPLAY_NAME,
        MediaStore.Video.Media.DURATION,
        MediaStore.Video.Media.SIZE
    )
    val result = mutableListOf<VideoFile>()
    var cursor: Cursor? = null
    try {
        cursor = app.contentResolver.query(
            collection, projection, null, null,
            "${MediaStore.Video.Media.DATE_ADDED} DESC"
        )
        cursor?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val nameCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val durationCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            val sizeCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                result.add(VideoFile(
                    ContentUris.withAppendedId(collection, id),
                    c.getString(nameCol) ?: "Untitled video",
                    c.getLong(durationCol),
                    c.getLong(sizeCol)
                ))
            }
        }
    } catch (_: SecurityException) {
        return emptyList()
    } catch (_: Exception) {
        return emptyList()
    } finally {
        cursor?.close()
    }
    return result
}

private fun formatTime(ms: Long): String {
    val total = (ms / 1000).coerceAtLeast(0)
    val hours = total / 3600
    val minutes = (total % 3600) / 60
    val seconds = total % 60
    return if (hours > 0) String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
    else String.format(Locale.US, "%02d:%02d", minutes, seconds)
}
